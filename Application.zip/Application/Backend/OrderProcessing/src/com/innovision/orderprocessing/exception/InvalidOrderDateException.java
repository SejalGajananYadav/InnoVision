package com.innovision.orderprocessing.exception;

public class InvalidOrderDateException extends Exception {

	public InvalidOrderDateException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidOrderDateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
