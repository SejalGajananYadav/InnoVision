package com.innovision.orderprocessing.exception;

public class InvoiceAlreadyExistsException extends Exception{

	public InvoiceAlreadyExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvoiceAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
