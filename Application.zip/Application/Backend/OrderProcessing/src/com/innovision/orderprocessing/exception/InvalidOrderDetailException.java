package com.innovision.orderprocessing.exception;

public class InvalidOrderDetailException extends Exception {

	public InvalidOrderDetailException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidOrderDetailException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
