package com.innovision.orderprocessing.exception;

public class NoPendingOrderException extends Exception{

	public NoPendingOrderException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoPendingOrderException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NoPendingOrderException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoPendingOrderException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoPendingOrderException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
