package com.innovision.orderprocessing.exception;

public class ConnectionNotEstablishedException extends Exception {

	public ConnectionNotEstablishedException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ConnectionNotEstablishedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
