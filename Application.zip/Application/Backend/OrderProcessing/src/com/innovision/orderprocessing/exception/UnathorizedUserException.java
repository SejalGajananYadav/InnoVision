package com.innovision.orderprocessing.exception;

public class UnathorizedUserException extends Exception {

	public UnathorizedUserException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UnathorizedUserException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
