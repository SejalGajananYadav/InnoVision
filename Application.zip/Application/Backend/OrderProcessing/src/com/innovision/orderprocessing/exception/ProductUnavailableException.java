package com.innovision.orderprocessing.exception;

public class ProductUnavailableException extends Exception{

	public ProductUnavailableException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductUnavailableException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
