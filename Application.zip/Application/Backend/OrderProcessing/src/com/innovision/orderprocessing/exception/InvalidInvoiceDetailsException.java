package com.innovision.orderprocessing.exception;

public class InvalidInvoiceDetailsException extends Exception {

	public InvalidInvoiceDetailsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidInvoiceDetailsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
