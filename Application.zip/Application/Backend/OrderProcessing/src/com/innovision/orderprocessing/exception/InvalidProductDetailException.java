package com.innovision.orderprocessing.exception;

public class InvalidProductDetailException extends Exception{

	public InvalidProductDetailException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidProductDetailException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
