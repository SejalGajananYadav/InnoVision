package com.innovision.orderprocessing.exception;

public class UserNotFoundException extends Exception{
	
	public UserNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
